





<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <div class="page-titles">
    <h4>Light Gallery</h4>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="javascript:void(0)"> Plugins</a></li>
      <li class="breadcrumb-item active"><a href="javascript:void(0)">Light Gallery</a></li>
    </ol>
  </div>
  <div class="row">
    <div class="col-lg-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Light Gallery</h4>
        </div>
        <div class="card-body pb-1">
          <div id="lightgallery" class="row">
            <a href="<?php echo e(asset('images/big/img1.jpg')); ?>" data-exthumbimage="<?php echo e(asset('images/big/img1.jpg')); ?>" data-src="<?php echo e(asset('images/big/img1.jpg')); ?>" class="col-lg-3 col-md-6 mb-4">
              <img src="<?php echo e(asset('images/big/img1.jpg')); ?>" style="width:100%;"/>
            </a>
            <a href="<?php echo e(asset('images/big/img2.jpg')); ?>" data-exthumbimage="<?php echo e(asset('images/big/img2.jpg')); ?>" data-src="<?php echo e(asset('images/big/img2.jpg')); ?>" class="col-lg-3 col-md-6 mb-4">
              <img src="<?php echo e(asset('images/big/img2.jpg')); ?>" style="width:100%;" />
            </a>
            <a href="<?php echo e(asset('images/big/img3.jpg')); ?>" data-exthumbimage="<?php echo e(asset('images/big/img3.jpg')); ?>" data-src="<?php echo e(asset('images/big/img3.jpg')); ?>" class="col-lg-3 col-md-6 mb-4">
              <img src="<?php echo e(asset('images/big/img3.jpg')); ?>" style="width:100%;" />
            </a>
            <a href="<?php echo e(asset('images/big/img4.jpg')); ?>" data-exthumbimage="<?php echo e(asset('images/big/img4.jpg')); ?>" data-src="<?php echo e(asset('images/big/img4.jpg')); ?>" class="col-lg-3 col-md-6 mb-4">
              <img src="<?php echo e(asset('images/big/img4.jpg')); ?>" style="width:100%;" />
            </a>
            <a href="<?php echo e(asset('images/big/img5.jpg')); ?>" data-exthumbimage="<?php echo e(asset('images/big/img5.jpg')); ?>" data-src="<?php echo e(asset('images/big/img5.jpg')); ?>" class="col-lg-3 col-md-6 mb-4">
              <img src="<?php echo e(asset('images/big/img5.jpg')); ?>" style="width:100%;"/>
            </a>
            <a href="<?php echo e(asset('images/big/img6.jpg')); ?>" data-exthumbimage="<?php echo e(asset('images/big/img6.jpg')); ?>" data-src="<?php echo e(asset('images/big/img6.jpg')); ?>" class="col-lg-3 col-md-6 mb-4">
              <img src="<?php echo e(asset('images/big/img6.jpg')); ?>" style="width:100%;" />
            </a>
            <a href="<?php echo e(asset('images/big/img7.jpg')); ?>" data-exthumbimage="<?php echo e(asset('images/big/img7.jpg')); ?>" data-src="<?php echo e(asset('images/big/img7.jpg')); ?>" class="col-lg-3 col-md-6 mb-4">
              <img src="<?php echo e(asset('images/big/img7.jpg')); ?>" style="width:100%;" />
            </a>
            <a href="<?php echo e(asset('images/big/img8.jpg')); ?>" data-exthumbimage="<?php echo e(asset('images/big/img8.jpg')); ?>" data-src="<?php echo e(asset('images/big/img8.jpg')); ?>" class="col-lg-3 col-md-6 mb-4">
              <img src="<?php echo e(asset('images/big/img8.jpg')); ?>" style="width:100%;" />
            </a>
          </div>
        </div>
      </div>
      <!-- /# card -->
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\mophy\resources\views/uc/lightgallery.blade.php ENDPATH**/ ?>